# Zyon FF Companion

Companion Android independente para Free Fire normal.

## Recursos
- Botão para abrir o pacote Android do Free Fire normal (`com.dts.freefireth`).
- Permissão de sobreposição e menu flutuante arrastável.
- Preferências locais persistidas.

## Compilar
Abra esta pasta no Android Studio e escolha **Build > Build APK(s)**.
APK de depuração: `app/build/outputs/apk/debug/app-debug.apk`.

## Limites
O painel é independente do jogo. Não captura tela, não lê memória, não injeta código, não desenha ESP de inimigos e não automatiza ou modifica a mira.
