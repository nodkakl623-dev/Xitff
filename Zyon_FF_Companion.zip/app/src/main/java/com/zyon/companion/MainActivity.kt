package com.zyon.companion

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zyon", MODE_PRIVATE) }
    private val purple = 0xFF7653E8.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 22)
            setBackgroundColor(0xFF11111B.toInt())
        }
        root.addView(TextView(this).apply {
            text = "ZYON FF COMPANION"
            textSize = 23f; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "PAINEL FLUTUANTE • CONFIGURAÇÕES LOCAIS"
            textSize = 11f; setTextColor(0xFFB9B3CC.toInt())
            setPadding(0, 7, 0, 24)
        })
        val launch = Button(this).apply {
            text = "ABRIR FREE FIRE"
            setOnClickListener { openFreeFire() }
        }
        root.addView(launch, LinearLayout.LayoutParams(-1, -2))
        val overlay = Button(this).apply {
            text = "ATIVAR MENU FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    Toast.makeText(this@MainActivity, "Menu ativado", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(overlay, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "\nCONFIGURAÇÕES"
            textSize = 14f; setTextColor(0xFFBDAAFF.toInt())
        })
        addToggle(root, "Mostrar painel compacto", "Exibe o menu sobre outros aplicativos", "compact", true)
        addToggle(root, "Vibração dos botões", "Preferência local da interface", "vibration", false)
        addToggle(root, "Manter última configuração", "Salva as opções neste aparelho", "persist", true)
        root.addView(TextView(this).apply {
            text = "\nO companion abre o Free Fire e mostra um painel independente. Não lê a tela do jogo, não acessa memória, não marca inimigos e não altera a mira ou partidas."
            textSize = 12f; setTextColor(0xFFB9B3CC.toInt())
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addToggle(root: LinearLayout, title: String, detail: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFF242435.toInt())
        }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        line.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        line.addView(sw); row.addView(line)
        row.addView(TextView(this).apply {
            text = detail; textSize = 11f; setTextColor(0xFFB9B3CC.toInt())
        })
        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun openFreeFire() {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
        if (launchIntent != null) startActivity(launchIntent)
        else Toast.makeText(this, "Free Fire normal não encontrado. Instale/abra o jogo primeiro.", Toast.LENGTH_LONG).show()
    }
}
