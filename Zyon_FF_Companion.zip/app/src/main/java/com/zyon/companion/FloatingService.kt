package com.zyon.companion

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xEE1D1B2B.toInt())
        }
        val header = TextView(this).apply {
            text = "ZYON  •  MENU  ×"
            textSize = 14f; setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 12)
            setOnClickListener { stopSelf() }
        }
        box.addView(header)
        box.addView(TextView(this).apply {
            text = "COMPANION ATIVO"
            textSize = 12f; setTextColor(0xFFBDAAFF.toInt())
        })
        box.addView(Button(this).apply {
            text = "ABRIR PAINEL"
            setOnClickListener {
                val i = Intent(this@FloatingService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        })
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 140 }
        panel = box
        wm.addView(box, params)
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ix = 0; var iy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    sx = e.rawX; sy = e.rawY; ix = params.x; iy = params.y; return true
                }
                if (e.action == MotionEvent.ACTION_MOVE) {
                    params.x = ix + (sx - e.rawX).toInt()
                    params.y = iy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, params); return true
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
